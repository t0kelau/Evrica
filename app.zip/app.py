from flask import Flask, render_template

app = Flask(__name__)

profiles = [
    {"name": "jhon", "surname": "Doe", "image": "card5.jpg"},
    {"name": "jane", "surname": "jij", "image": "card3.jpg"}
]

@app.route("/")
def home():
    return render_template("Homework09_1.html")

@app.route("/LogIn")
def LogIn():
    return render_template("LogIn.html")

@app.route("/Signin")
def Signin():
    return render_template("Signin.html")

@app.route("/profile/<int:profile_id>")
def profile(profile_id):
    print("Received profile id", profile_id)
    return render_template("profile.html", user=profiles[profile_id])

app.run(debug=True)